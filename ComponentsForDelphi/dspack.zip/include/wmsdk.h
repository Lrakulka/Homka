//*@@@+++@@@@******************************************************************
//
// Microsoft Windows Media
// Copyright (C) Microsoft Corporation. All rights reserved.
//
//*@@@---@@@@******************************************************************
//
#pragma once
#include <windows.h>
#include "wmsdkidl.h"
#include "asferr.h"
#include "nserror.h"
